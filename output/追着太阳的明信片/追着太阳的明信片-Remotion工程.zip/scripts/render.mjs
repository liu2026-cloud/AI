import {spawnSync} from 'node:child_process';
import {mkdirSync} from 'node:fs';
mkdirSync('out',{recursive:true});
const browser=process.env.CHROMIUM_EXECUTABLE || '/usr/bin/chromium';
const cmd=[ 'render','src/index.ts','SunPostcard','out/video-silent.mp4','--browser-executable='+browser,'--concurrency=2','--codec=h264','--crf=20' ];
let r=spawnSync(process.execPath,['node_modules/@remotion/cli/remotion-cli.js',...cmd],{stdio:'inherit'}); if(r.status!==0) process.exit(r.status||1);
r=spawnSync(process.env.FFMPEG_EXECUTABLE||'ffmpeg',['-y','-i','out/video-silent.mp4','-i','public/music.wav','-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','256k','-ar','48000','-t','46.433333','-movflags','+faststart','out/追着太阳的明信片.mp4'],{stdio:'inherit'});if(r.status!==0)process.exit(r.status||1);
