import React from 'react';

type CharacterProps = {x?: number; y?: number; scale?: number; rotate?: number; opacity?: number; wave?: number};
const ink = '#593e3a';
const styleFor = ({x=0,y=0,scale=1,rotate=0,opacity=1}: CharacterProps): React.CSSProperties => ({
  position:'absolute',left:x,top:y,width:360*scale,height:540*scale,transform:`rotate(${rotate}deg)`,transformOrigin:'50% 85%',opacity,overflow:'visible',pointerEvents:'none'
});

/** Cute storybook girl, 360 × 540 viewBox, x/y are upper-left in composition coordinates. */
export const Girl: React.FC<CharacterProps> = (props) => <svg style={styleFor(props)} viewBox="0 0 360 540" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="181" cy="518" rx="106" ry="13" fill="#866b63" opacity=".14"/>
  {/* Back of the hair and the body */}
  <path d="M89 180 Q82 84 176 75 Q273 72 272 187 L285 296 Q257 320 224 298 L127 299 Q95 318 74 293 Z" fill="#634342" stroke={ink} strokeWidth="7" strokeLinejoin="round"/>
  <path d="M131 290 Q104 299 93 337 L75 401 Q73 416 88 421 Q102 424 108 410 L127 367" fill="#f6c5a8" stroke={ink} strokeWidth="6" strokeLinecap="round"/>
  <path d="M229 291 Q257 299 268 333 L286 387 Q289 402 276 407 Q263 410 257 396 L237 366" fill="#f6c5a8" stroke={ink} strokeWidth="6" strokeLinecap="round"/>
  <path d="M125 318 Q135 301 151 298 L211 298 Q228 300 238 318 L254 434 Q181 457 106 434 Z" fill="#f5d7aa" stroke={ink} strokeWidth="7" strokeLinejoin="round"/>
  <path d="M119 408 Q179 423 242 408 L247 433 Q182 450 112 433 Z" fill="#f0b993" opacity=".7"/>
  <path d="M145 438 L144 488 Q143 501 129 503 L116 503 Q106 504 106 512 Q106 521 119 521 L154 521 Q166 520 166 508 L168 444" fill="#f5c7aa" stroke={ink} strokeWidth="6" strokeLinejoin="round"/>
  <path d="M196 444 L197 508 Q197 520 208 521 L243 521 Q256 521 256 512 Q256 504 245 503 L232 503 Q218 501 217 488 L217 438" fill="#f5c7aa" stroke={ink} strokeWidth="6" strokeLinejoin="round"/>
  <path d="M109 502 Q124 496 145 499 L154 502 L154 518 L116 519 Q104 518 106 511 Z M206 502 L216 499 Q237 496 252 502 L256 511 Q258 518 245 519 L207 518 Z" fill="#b9665d"/>
  {/* Face, hair, expression */}
  <path d="M101 169 Q103 91 180 88 Q258 91 260 170 L257 205 Q253 268 181 275 Q109 268 105 205 Z" fill="#f9d2b6" stroke={ink} strokeWidth="7"/>
  <path d="M103 167 Q98 92 177 86 Q253 85 259 160 Q243 147 231 123 Q218 150 178 148 Q144 149 120 133 Q115 157 103 167 Z" fill="#704947" stroke={ink} strokeWidth="6" strokeLinejoin="round"/>
  <path d="M128 111 Q151 91 174 97" fill="none" stroke="#9b6c61" strokeWidth="6" strokeLinecap="round"/>
  <ellipse cx="146" cy="193" rx="8" ry="12" fill="#503b3a"/><ellipse cx="215" cy="193" rx="8" ry="12" fill="#503b3a"/>
  <circle cx="143" cy="188" r="2.7" fill="#fff"/><circle cx="212" cy="188" r="2.7" fill="#fff"/>
  <ellipse cx="129" cy="215" rx="15" ry="8" fill="#e99596" opacity=".57"/><ellipse cx="231" cy="215" rx="15" ry="8" fill="#e99596" opacity=".57"/>
  <path d="M169 218 Q181 230 193 218" fill="none" stroke="#9c5e59" strokeWidth="5" strokeLinecap="round"/>
  {/* signature red scarf */}
  <path d="M124 275 Q180 293 239 275 L246 304 Q185 326 118 305 Z" fill="#e35c59" stroke={ink} strokeWidth="6" strokeLinejoin="round"/>
  <path d="M188 304 Q201 303 212 298 L216 377 Q205 386 190 380 Z" fill="#e35c59" stroke={ink} strokeWidth="5" strokeLinejoin="round"/>
  <path d="M193 368 L212 365 M194 375 L213 372" stroke="#f7b1a0" strokeWidth="4" strokeLinecap="round"/>
  <path d="M123 289 Q176 307 231 289" fill="none" stroke="#f18b79" strokeWidth="5" strokeLinecap="round"/>
  <circle cx="247" cy="117" r="13" fill="#e95e60" stroke={ink} strokeWidth="4"/><path d="M247 106 L247 128 M237 117 L257 117" stroke="#fff0d4" strokeWidth="3"/>
</svg>;

/** Cute storybook boy in a blue guard uniform, 360 × 540 viewBox. */
export const Boy: React.FC<CharacterProps> = (props) => <svg style={styleFor(props)} viewBox="0 0 360 540" xmlns="http://www.w3.org/2000/svg">
  <ellipse cx="181" cy="518" rx="106" ry="13" fill="#866b63" opacity=".14"/>
  {/* legs and polished boots */}
  <path d="M125 407 L127 488 Q127 500 115 503 L104 505 Q94 507 96 514 Q97 521 110 521 L153 521 Q166 521 166 509 L169 416" fill="#37496b" stroke={ink} strokeWidth="6" strokeLinejoin="round"/>
  <path d="M192 416 L195 509 Q195 521 208 521 L251 521 Q264 521 265 514 Q267 507 257 505 L246 503 Q234 500 234 488 L236 407" fill="#37496b" stroke={ink} strokeWidth="6" strokeLinejoin="round"/>
  <path d="M97 505 Q116 496 145 500 L154 504 L154 519 L108 519 Q97 519 97 512 Z M207 504 L216 500 Q245 496 264 505 L264 512 Q264 519 253 519 L207 519 Z" fill="#31364c"/>
  {/* Sleeves and hands */}
  <path d="M128 287 Q99 290 87 322 L70 382 Q66 397 81 402 Q94 406 100 392 L118 355" fill="#3d6996" stroke={ink} strokeWidth="6" strokeLinecap="round"/>
  <path d="M232 287 Q261 290 273 322 L290 382 Q294 397 279 402 Q266 406 260 392 L242 355" fill="#3d6996" stroke={ink} strokeWidth="6" strokeLinecap="round"/>
  <circle cx="82" cy="400" r="16" fill="#f5c8aa" stroke={ink} strokeWidth="5"/><circle cx="278" cy="400" r="16" fill="#f5c8aa" stroke={ink} strokeWidth="5"/>
  <path d="M123 296 Q136 282 153 279 L207 279 Q226 282 238 296 L250 419 Q181 438 110 419 Z" fill="#4777a5" stroke={ink} strokeWidth="7" strokeLinejoin="round"/>
  <path d="M122 310 Q180 327 238 310 M114 396 Q181 412 246 396" fill="none" stroke="#eecb78" strokeWidth="5"/>
  <path d="M180 316 L180 411" stroke="#edcb7b" strokeWidth="5"/>
  <g fill="#f8df9c"><circle cx="164" cy="337" r="4"/><circle cx="196" cy="337" r="4"/><circle cx="164" cy="361" r="4"/><circle cx="196" cy="361" r="4"/><circle cx="164" cy="385" r="4"/><circle cx="196" cy="385" r="4"/></g>
  <path d="M120 312 L106 316 M240 312 L254 316" stroke="#f6d990" strokeWidth="8" strokeLinecap="round"/>
  {/* face */}
  <path d="M101 173 Q103 101 180 98 Q257 101 259 173 L256 207 Q252 270 180 276 Q108 270 104 207 Z" fill="#f9d0af" stroke={ink} strokeWidth="7"/>
  <path d="M103 170 Q103 103 180 99 Q254 99 257 166 Q241 151 230 135 Q204 152 167 145 Q137 143 119 130 Q114 155 103 170 Z" fill="#624a45" stroke={ink} strokeWidth="6" strokeLinejoin="round"/>
  <ellipse cx="145" cy="193" rx="8" ry="12" fill="#503b3a"/><ellipse cx="215" cy="193" rx="8" ry="12" fill="#503b3a"/>
  <circle cx="142" cy="188" r="2.7" fill="#fff"/><circle cx="212" cy="188" r="2.7" fill="#fff"/>
  <ellipse cx="128" cy="214" rx="14" ry="8" fill="#e99596" opacity=".48"/><ellipse cx="232" cy="214" rx="14" ry="8" fill="#e99596" opacity=".48"/>
  <path d="M169 220 Q180 230 192 220" fill="none" stroke="#9c5e59" strokeWidth="5" strokeLinecap="round"/>
  {/* guard hat, gold emblem */}
  <path d="M112 131 L119 38 Q180 17 241 38 L248 131 Z" fill="#37557c" stroke={ink} strokeWidth="7" strokeLinejoin="round"/>
  <path d="M121 44 Q181 27 239 44 L241 65 Q181 51 119 65 Z" fill="#4e7198"/>
  <path d="M102 130 Q180 117 258 130 L261 151 Q180 140 99 151 Z" fill="#293c5b" stroke={ink} strokeWidth="6" strokeLinejoin="round"/>
  <path d="M108 132 Q181 122 253 132" fill="none" stroke="#e8c576" strokeWidth="5"/>
  <circle cx="180" cy="84" r="19" fill="#eac878" stroke="#9b754f" strokeWidth="4"/>
  <path d="M180 96 C158 84 171 71 180 80 C189 71 202 84 180 96 Z" fill="#df695e"/>
  <path d="M124 285 Q180 302 237 285" fill="none" stroke="#f0cf87" strokeWidth="6" strokeLinecap="round"/>
</svg>;
