import React from 'react';
import {AbsoluteFill, Composition, interpolate, useCurrentFrame, useVideoConfig, staticFile} from 'remotion';
import {Background} from './Background';
import {Girl, Boy} from './Characters';
import './style.css';

// These lyric offsets are estimates from a reference recording. Adjust this table
// after listening to the exact supplied recording; all values are seconds.
export const lyricStartOffset = 1.24;
const lines = [
 {t:0, text:['祈祷你像','英勇的禁卫军'],bg:'room',kind:'wish'},
 {t:3.765,text:['动也不动地','守护爱情'],bg:'garden',kind:'guard'},
 {t:7.517,text:['你在回忆里','留下的脚印'],bg:'garden',kind:'memory'},
 {t:11.237,text:['是我爱的','风景'],bg:'garden',kind:'landscape'},
 {t:14.991,text:['我要送你','日不落的想念'],bg:'room',kind:'write'},
 {t:18.757,text:['寄出代表爱的','明信片'],bg:'room',kind:'letter'},
 {t:22.507,text:['我要送你','日不落的爱恋'],bg:'travel',kind:'flight'},
 {t:26.257,text:['心牵着心','把世界走遍'],bg:'travel',kind:'journey'},
 {t:30.010,text:['你就是庆典','你就是晴天'],bg:'party',kind:'party'},
 {t:33.757,text:['我的爱','未眠'],bg:'night',kind:'night'},
 {t:37.502,text:['不落的想念','飞在你身边'],bg:'night',kind:'flynight'},
 {t:41.262,text:['我的爱','未眠'],bg:'night',kind:'final'},
] as const;
type Kind=(typeof lines)[number]['kind'];
const HEART='M0 12 C-2 -4 -21 -5 -22 7 C-23 17 -11 25 0 33 C11 25 23 17 22 7 C21 -5 2 -4 0 12Z';
const clamp=(n:number,min=0,max=1)=>Math.max(min,Math.min(max,n));
const smooth=(n:number)=>{const v=clamp(n);return v*v*(3-2*v)};
const enter=(f:number)=>smooth(f/13);
const Heart: React.FC<{x:number,y:number,s?:number,color?:string,opacity?:number,rotate?:number}> = ({x,y,s=1,color='#e97e76',opacity=1,rotate=0}) => <svg width={50*s} height={50*s} viewBox="-25 -8 50 50" style={{position:'absolute',left:x,top:y,opacity,transform:`rotate(${rotate}deg)`}}><path d={HEART} fill={color}/></svg>;
const PaperPlane: React.FC<{x:number,y:number,s?:number,rotate?:number}> = ({x,y,s=1,rotate=0}) => <svg viewBox="0 0 240 140" width={240*s} height={140*s} style={{position:'absolute',left:x,top:y,transform:`rotate(${rotate}deg)`,overflow:'visible',filter:'drop-shadow(5px 8px 0px #916d6133)'}}><path d="M6 70 L228 7 L172 131 L117 94 L84 125 L75 82Z" fill="#fff8e7" stroke="#b17e70" strokeWidth="5" strokeLinejoin="round"/><path d="M75 82 L228 7 L117 94 L84 125 L84 91" fill="none" stroke="#d69b8a" strokeWidth="4"/><path d={HEART} transform="translate(135 42) scale(.7)" fill="#ec807a"/></svg>;
const Postcard:React.FC<{x:number,y:number,s?:number,rotate?:number}> = ({x,y,s=1,rotate=0})=><svg width={460*s} height={300*s} viewBox="0 0 460 300" style={{position:'absolute',left:x,top:y,transform:`rotate(${rotate}deg)`,filter:'drop-shadow(8px 10px 0px #9a72532c)'}}><rect x="4" y="4" width="452" height="292" rx="20" fill="#fff6e5" stroke="#c6927b" strokeWidth="8"/><path d="M250 44 V260" stroke="#dfbda4" strokeWidth="4"/><path d="M279 140 H410 M279 171 H410 M279 202 H390" stroke="#d6b7a5" strokeWidth="5" strokeLinecap="round"/><rect x="350" y="30" width="68" height="72" rx="8" fill="#edaaa0" stroke="#d68079" strokeWidth="4" strokeDasharray="5 4"/><path d={HEART} transform="translate(384 42) scale(.8)" fill="#fff1dd"/><path d="M37 214 Q84 150 120 192 Q151 134 224 192 L224 244 H37Z" fill="#a6c998"/><circle cx="165" cy="93" r="35" fill="#ffcf70"/><path d={HEART} transform="translate(103 96) scale(1.3)" fill="#ee8c81"/></svg>;
const Caption:React.FC<{text:readonly string[],frame:number,kind:Kind|'opening'}> = ({text,frame,kind})=>{
 const e=enter(frame); const sky=['guard','memory','landscape'].includes(kind);
 const travel=['flight','journey'].includes(kind); const night=['night','flynight','final'].includes(kind);
 const party=kind==='party'; const paper=['opening','wish','write','letter'].includes(kind);
 const right=['landscape','letter','journey','flynight'].includes(kind);
 const center=kind==='party'||kind==='final';
 const x=center?540:right?1070:kind==='flight'?100:105;
 const y=center?120:kind==='memory'?120:kind==='letter'?140:kind==='journey'?115:kind==='flynight'?120:night?170:145;
 const rotation=paper?(right?4:-3):travel?(right?3:-4):party?-1:0;
 const card:React.CSSProperties=paper?{background:'rgba(255,249,231,.95)',border:'4px solid #e4b29b',borderRadius:'8px 28px 14px 25px',boxShadow:'0 9px 0 #bb8f7b55',padding:'18px 30px 22px'}:party?{background:'#f7bd80',border:'5px solid #fff1ca',borderRadius:'8px 38px 8px 38px',boxShadow:'0 10px 0 #b77e6b55',padding:'17px 35px 20px'}:travel?{background:'rgba(255,250,232,.88)',border:'3px dashed #e8a78f',borderRadius:'50px 15px 50px 15px',padding:'15px 30px 20px'}:{padding:'12px 18px'};
 const fg=night?'#fff2cc':sky?'#fff9e9':'#694d4e'; const second=night?'#ffdc9b':sky?'#fff2bf':'#d36c63';
 const shadow=night?'0 3px 0 #6e638c, 0 0 25px #ffd9a7':sky?'0 4px 0 #83aab0, 3px 8px 0 #7b9b9880':'none';
 return <div style={{position:'absolute',left:x,top:y,transform:`translateY(${(1-e)*30}px) rotate(${rotation}deg)`,opacity:e}}>
  <div style={{display:'inline-block',...card,color:fg,fontFamily:'MVFont, sans-serif',fontSize:70,lineHeight:1.34,letterSpacing:3,whiteSpace:'nowrap',textShadow:shadow}}>{text.map((line,i)=><div key={line} style={{color:i===1?second:fg,transform:`translateX(${(1-smooth((frame-i*6)/13))*18}px)`,opacity:smooth((frame-i*6)/13)}}>{line}</div>)}</div>
  {paper&&<><span style={{position:'absolute',left:28,top:-13,width:100,height:25,background:'#f2ac92',opacity:.8,transform:'rotate(-6deg)'}}/><Heart x={-22} y={-20} s={.55} color="#ee9588" rotate={-18}/></>}
  {travel&&<><span style={{position:'absolute',left:20,bottom:-22,width:300,borderTop:'4px dashed #df9e8a'}}/><Heart x={310} y={175} s={.45} color="#efac82" rotate={20}/></>}
  {night&&<><span style={{position:'absolute',left:-18,top:5,color:'#ffdd9d',fontSize:28}}>✦</span><span style={{position:'absolute',right:-32,bottom:10,color:'#ffdd9d',fontSize:24}}>✦</span></>}
 </div>
};
const Effects:React.FC<{kind:Kind,frame:number}> = ({kind,frame:f})=>{
 if(kind==='memory')return <>{Array.from({length:6},(_,i)=><div key={i} style={{position:'absolute',left:230+i*130,top:770+i%2*35,opacity:clamp((f-i*10)/8),transform:`rotate(-25deg) scale(${.75+i*.06})`,fontSize:62,color:'#ce9d8e'}}>♥</div>)}</>;
 if(kind==='write'||kind==='letter')return <><Postcard x={960} y={570} s={.95} rotate={-6}/>{kind==='letter'&&<PaperPlane x={1250+f*3} y={440-f*1.1} s={.72} rotate={-14}/>}</>;
 if(kind==='flight'||kind==='journey')return <><PaperPlane x={310+f*6} y={550-Math.sin(f/20)*85} s={.75} rotate={-12}/>{Array.from({length:4},(_,i)=><Heart key={i} x={400+i*80+f*4} y={630+Math.sin(i+f/20)*30} s={.5} opacity={.45}/>)}</>;
 if(kind==='flynight'||kind==='final')return <PaperPlane x={800+Math.sin(f/24)*190} y={270+Math.cos(f/24)*80} s={.55} rotate={-10+Math.sin(f/20)*10}/>;
 if(kind==='guard')return <Heart x={1050} y={420} s={1.6} opacity={.85}/>;
 if(kind==='party')return <>{Array.from({length:10},(_,i)=><Heart key={i} x={120+i*175} y={70+(i%3)*100+Math.sin(f/20+i)*18} s={.35+(i%3)*.1} color={['#ef897f','#ffce75','#f6dcb5'][i%3]}/>)}</>;
 return null;
};
const People:React.FC<{kind:Kind,frame:number}>=({kind,frame:f})=>{
 const bob=Math.sin(f/15)*4; const s=1.12;
 switch(kind){
  case 'wish':return <><Girl x={830} y={450+bob} scale={1.0}/><Boy x={1370} y={260} scale={.60} opacity={.76} rotate={4}/></>;
  case 'guard':return <><Boy x={1125} y={400+bob*.2} scale={1.16}/><Girl x={1390} y={500+bob} scale={.82}/></>;
  case 'memory':return <><Boy x={1330} y={450+bob} scale={.85} opacity={.7}/><Girl x={1040} y={475+bob} scale={.8} opacity={.7}/></>;
  case 'landscape':return <><Girl x={930} y={500+bob} scale={.87}/><Boy x={1225} y={500-bob} scale={.87}/></>;
  case 'write':case 'letter':return <Girl x={680} y={460+bob} scale={.95}/>;
  case 'flight':return <><Girl x={75} y={600+bob} scale={.62}/><Boy x={1530} y={585-bob} scale={.67}/></>;
  case 'journey':return <><Girl x={1250} y={490+bob} scale={.84}/><Boy x={1450} y={490-bob} scale={.84}/></>;
  case 'party':return <><Girl x={890} y={450+bob} scale={1.04}/><Boy x={1190} y={450-bob} scale={1.04}/></>;
  case 'night':case 'flynight':case 'final':return <><Girl x={690} y={520+bob*.3} scale={.9}/><Boy x={980} y={520-bob*.3} scale={.9}/></>;
 }
};
const Movie:React.FC=()=>{
 const frame=useCurrentFrame(); const {fps}=useVideoConfig(); const seconds=frame/fps;
 let index=-1; for(let i=0;i<lines.length;i++) if(seconds>=lyricStartOffset+lines[i].t)index=i;
 const opening=index<0; const item=lines[Math.max(index,0)]; const local=opening?frame:frame-Math.round((lyricStartOffset+item.t)*fps);
 const fade=opening?1:clamp(local/7);
 const beatPhase=((seconds-0.01)%(60/128)+(60/128))%(60/128);
 const beatPulse=Math.exp(-beatPhase*8);
 const zoom=1+0.012*beatPulse;
 return <AbsoluteFill style={{background:'#fbe8cf',overflow:'hidden'}}>
  <Background variant={opening?'room':item.bg} frame={frame}/>
  <div style={{position:'absolute',inset:0,opacity:fade,transform:`scale(${zoom})`,transformOrigin:'50% 72%'}}><People kind={opening?'wish':item.kind} frame={local}/><Effects kind={item.kind} frame={local}/></div>
  {opening?<Caption text={['追着太阳的','明信片']} frame={frame} kind="opening"/>:<Caption text={item.text} frame={local} kind={item.kind}/>}
  <div style={{position:'absolute',inset:0,border:'18px solid #fff7e3',borderRadius:20,boxSizing:'border-box',pointerEvents:'none',opacity:.55}}/>
 </AbsoluteFill>;
};
export const RemotionRoot:React.FC=()=> <Composition id="SunPostcard" component={Movie} durationInFrames={1393} fps={30} width={1920} height={1080}/>;
