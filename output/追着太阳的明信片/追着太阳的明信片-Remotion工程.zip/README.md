# 追着太阳的明信片 · Remotion MV

横屏 1920×1080、30 帧/秒、约 46.43 秒。源音轨来自 `10月19日.mp4`，完整音轨放在 `public/music.wav`，画面及人物由 React/SVG 制作，歌词融入明信片、天空、横幅及夜空场景。

## 渲染

需要 Node.js、FFmpeg 和 Chromium：

```bash
npm ci
npm run render
```

如果浏览器不在 `/usr/bin/chromium`，请用 `CHROMIUM_EXECUTABLE` 设置可执行文件路径；FFmpeg 可用 `FFMPEG_EXECUTABLE` 指定。渲染出的文件是 `out/追着太阳的明信片.mp4`。

## 时间线说明

`src/Root.tsx` 中 `lyricStartOffset` 和 `lines` 定义歌词开始时间：根据音乐音高与公开歌曲标注自动比对得到第一句约 1.24 秒，其他句点参考歌曲 LRC；逐字时间没有人工听辨确认。可以试听后调整偏移或每句 `t`，并重新渲染。背景人物的节拍动效基于约 128 BPM，低频强拍相位约 0.01 秒。

人物位于 `src/Characters.tsx`，背景位于 `src/Background.tsx`；中文字体子集及其许可位于 `public`。
